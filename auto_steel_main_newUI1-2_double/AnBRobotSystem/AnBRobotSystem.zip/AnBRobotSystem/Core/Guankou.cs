﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnBRobotSystem.Core
{
    public static class Guankou
    {
        public static double area = 0;
        public static int Inital_light = 0;
        public static int Fall_edga_light = 0;
        public static string shape = "";
        public static void get_Guankou_data()
        {
            
        }
    }
}
