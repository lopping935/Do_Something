﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnBRobotSystem.Core
{
    class Tieliu
    {
        public static bool Get_iron = false;
        public static double area = 0;
       // public static int iron_tempor = 0;
        public static string shape = "";
        public static void get_Tieliu_data()
        {

        }
    }
}
