﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace AnBRobotSystem.Utlis
{
    class Auto_steel_helper
    {
        public static void mainlog(string model, string strmsg)
        {
            
        }
    }
}
