﻿namespace AnBRobotSystem.ChildForm
{
    partial class Main_process
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_process));
            this.uiProcessBar1 = new Sunny.UI.UIProcessBar();
            this.zt_ScrollingText1 = new Sunny.UI.UIScrollingText();
            this.zt_Panel1 = new Sunny.UI.UIPanel();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiButton1_back = new Sunny.UI.UIButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.折铁 = new Sunny.UI.UIGroupBox();
            this.weight_speed_uiLabel = new Sunny.UI.UILabel();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.tb_limit = new Sunny.UI.UILedBulb();
            this.TB_weight = new Sunny.UI.UILabel();
            this.aim_weight_uiLabel3 = new Sunny.UI.UILabel();
            this.uiLabel7 = new Sunny.UI.UILabel();
            this.uiLabel18 = new Sunny.UI.UILabel();
            this.uiLabel16 = new Sunny.UI.UILabel();
            this.TB_hight = new Sunny.UI.UILabel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.A_go = new Sunny.UI.UIHeaderButton();
            this.B_go = new Sunny.UI.UIHeaderButton();
            this.A_back = new Sunny.UI.UIHeaderButton();
            this.B_back = new Sunny.UI.UIHeaderButton();
            this.TL_panel1 = new System.Windows.Forms.Panel();
            this.main_tl_vmRenderControl1 = new VMControls.Winform.Release.VmRenderControl();
            this.uiGroupBox2 = new Sunny.UI.UIGroupBox();
            this.uiLabel31 = new Sunny.UI.UILabel();
            this.B_MODEL = new Sunny.UI.UILedBulb();
            this.GBB_now_weight = new Sunny.UI.UILabel();
            this.uiLabel32 = new Sunny.UI.UILabel();
            this.B_TBK_vision = new Sunny.UI.UILedBulb();
            this.ui_gbb_angle = new Sunny.UI.UILabel();
            this.uiLabel34 = new Sunny.UI.UILabel();
            this.uiLabel10 = new Sunny.UI.UILabel();
            this.B_120_uiLedBulb4 = new Sunny.UI.UILedBulb();
            this.uiLabel35 = new Sunny.UI.UILabel();
            this.uiLabel24 = new Sunny.UI.UILabel();
            this.uiLabel25 = new Sunny.UI.UILabel();
            this.B_0_uiLedBulb5 = new Sunny.UI.UILedBulb();
            this.uiLabel28 = new Sunny.UI.UILabel();
            this.uiLabel29 = new Sunny.UI.UILabel();
            this.GBB_getpow = new Sunny.UI.UILedBulb();
            this.B_TL = new Sunny.UI.UILedBulb();
            this.GBB_num = new Sunny.UI.UILabel();
            this.uiLabel30 = new Sunny.UI.UILabel();
            this.B_GBK_vision = new Sunny.UI.UILedBulb();
            this.uiGroupBox1 = new Sunny.UI.UIGroupBox();
            this.A_MODEL = new Sunny.UI.UILedBulb();
            this.A_TBK_vision = new Sunny.UI.UILedBulb();
            this.A_120_uiLedBulb2 = new Sunny.UI.UILedBulb();
            this.uiLabel9 = new Sunny.UI.UILabel();
            this.uiLabel13 = new Sunny.UI.UILabel();
            this.uiLabel8 = new Sunny.UI.UILabel();
            this.A_0_uiLedBulb1 = new Sunny.UI.UILedBulb();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.A_TL = new Sunny.UI.UILedBulb();
            this.ui_gba_angle = new Sunny.UI.UILabel();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.uiLabel27 = new Sunny.UI.UILabel();
            this.A_GBK_vision = new Sunny.UI.UILedBulb();
            this.GBA_getpow = new Sunny.UI.UILedBulb();
            this.GBA_num = new Sunny.UI.UILabel();
            this.uiLabel19 = new Sunny.UI.UILabel();
            this.GBA_now_weight = new Sunny.UI.UILabel();
            this.uiLabel11 = new Sunny.UI.UILabel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.GBB_img = new Sunny.UI.UIImageButton();
            this.GBA_img = new Sunny.UI.UIImageButton();
            this.cw_Panel2 = new Sunny.UI.UIPanel();
            this.temp_weight = new Sunny.UI.UILabel();
            this.uiLabel21 = new Sunny.UI.UILabel();
            this.CW_tbnum = new Sunny.UI.UILabel();
            this.uiLabel17 = new Sunny.UI.UILabel();
            this.uiProcessBar2 = new Sunny.UI.UIProcessBar();
            this.uiScrollingText2 = new Sunny.UI.UIScrollingText();
            this.dz_Panel3 = new Sunny.UI.UIPanel();
            this.dz_weight = new Sunny.UI.UILabel();
            this.uiLabel23 = new Sunny.UI.UILabel();
            this.DZ_tbnum = new Sunny.UI.UILabel();
            this.uiLabel20 = new Sunny.UI.UILabel();
            this.uiProcessBar3 = new Sunny.UI.UIProcessBar();
            this.uiScrollingText3 = new Sunny.UI.UIScrollingText();
            this.zt_Panel1.SuspendLayout();
            this.折铁.SuspendLayout();
            this.TL_panel1.SuspendLayout();
            this.uiGroupBox2.SuspendLayout();
            this.uiGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GBB_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GBA_img)).BeginInit();
            this.cw_Panel2.SuspendLayout();
            this.dz_Panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiProcessBar1
            // 
            this.uiProcessBar1.BackColor = System.Drawing.Color.Transparent;
            this.uiProcessBar1.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiProcessBar1.Enabled = false;
            this.uiProcessBar1.FillColor = System.Drawing.Color.Transparent;
            this.uiProcessBar1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiProcessBar1.ForeColor = System.Drawing.Color.LawnGreen;
            this.uiProcessBar1.Location = new System.Drawing.Point(326, 450);
            this.uiProcessBar1.Maximum = 220;
            this.uiProcessBar1.MinimumSize = new System.Drawing.Size(70, 5);
            this.uiProcessBar1.Name = "uiProcessBar1";
            this.uiProcessBar1.Radius = 50;
            this.uiProcessBar1.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightBottom | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiProcessBar1.RectColor = System.Drawing.Color.Red;
            this.uiProcessBar1.ShowFocusColor = true;
            this.uiProcessBar1.Size = new System.Drawing.Size(236, 160);
            this.uiProcessBar1.Style = Sunny.UI.UIStyle.Custom;
            this.uiProcessBar1.StyleCustomMode = true;
            this.uiProcessBar1.TabIndex = 36;
            this.uiProcessBar1.Text = "uiProcessBar1";
            // 
            // zt_ScrollingText1
            // 
            this.zt_ScrollingText1.BackColor = System.Drawing.Color.Transparent;
            this.zt_ScrollingText1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.zt_ScrollingText1.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.zt_ScrollingText1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.zt_ScrollingText1.Location = new System.Drawing.Point(358, 616);
            this.zt_ScrollingText1.MinimumSize = new System.Drawing.Size(1, 1);
            this.zt_ScrollingText1.Name = "zt_ScrollingText1";
            this.zt_ScrollingText1.Size = new System.Drawing.Size(180, 24);
            this.zt_ScrollingText1.Style = Sunny.UI.UIStyle.Custom;
            this.zt_ScrollingText1.TabIndex = 53;
            this.zt_ScrollingText1.Text = "铁水包受铁位";
            // 
            // zt_Panel1
            // 
            this.zt_Panel1.Controls.Add(this.uiButton1);
            this.zt_Panel1.Controls.Add(this.uiButton1_back);
            this.zt_Panel1.Controls.Add(this.label2);
            this.zt_Panel1.Controls.Add(this.label1);
            this.zt_Panel1.Controls.Add(this.折铁);
            this.zt_Panel1.Controls.Add(this.A_go);
            this.zt_Panel1.Controls.Add(this.B_go);
            this.zt_Panel1.Controls.Add(this.A_back);
            this.zt_Panel1.Controls.Add(this.B_back);
            this.zt_Panel1.Controls.Add(this.TL_panel1);
            this.zt_Panel1.Controls.Add(this.uiGroupBox2);
            this.zt_Panel1.Controls.Add(this.uiProcessBar1);
            this.zt_Panel1.Controls.Add(this.uiGroupBox1);
            this.zt_Panel1.Controls.Add(this.GBB_img);
            this.zt_Panel1.Controls.Add(this.GBA_img);
            this.zt_Panel1.Controls.Add(this.zt_ScrollingText1);
            this.zt_Panel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.zt_Panel1.ForeColor = System.Drawing.Color.Black;
            this.zt_Panel1.Location = new System.Drawing.Point(9, 38);
            this.zt_Panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.zt_Panel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.zt_Panel1.Name = "zt_Panel1";
            this.zt_Panel1.RectColor = System.Drawing.Color.Red;
            this.zt_Panel1.Size = new System.Drawing.Size(881, 804);
            this.zt_Panel1.Style = Sunny.UI.UIStyle.Custom;
            this.zt_Panel1.StyleCustomMode = true;
            this.zt_Panel1.TabIndex = 56;
            this.zt_Panel1.Text = null;
            this.zt_Panel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1.Location = new System.Drawing.Point(211, 9);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.Size = new System.Drawing.Size(100, 35);
            this.uiButton1.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton1.TabIndex = 92;
            this.uiButton1.Text = "2号回罐";
            this.uiButton1.Click += new System.EventHandler(this.uiButton1_Click_1);
            // 
            // uiButton1_back
            // 
            this.uiButton1_back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1_back.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1_back.Location = new System.Drawing.Point(570, 9);
            this.uiButton1_back.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1_back.Name = "uiButton1_back";
            this.uiButton1_back.Size = new System.Drawing.Size(100, 35);
            this.uiButton1_back.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton1_back.TabIndex = 59;
            this.uiButton1_back.Text = "1号回罐";
            this.uiButton1_back.Click += new System.EventHandler(this.uiButton1_back_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 50F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(797, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 90);
            this.label2.TabIndex = 91;
            this.label2.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 50F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(5, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 90);
            this.label1.TabIndex = 90;
            this.label1.Text = "2";
            // 
            // 折铁
            // 
            this.折铁.Controls.Add(this.weight_speed_uiLabel);
            this.折铁.Controls.Add(this.uiLabel3);
            this.折铁.Controls.Add(this.tb_limit);
            this.折铁.Controls.Add(this.TB_weight);
            this.折铁.Controls.Add(this.aim_weight_uiLabel3);
            this.折铁.Controls.Add(this.uiLabel7);
            this.折铁.Controls.Add(this.uiLabel18);
            this.折铁.Controls.Add(this.uiLabel16);
            this.折铁.Controls.Add(this.TB_hight);
            this.折铁.Controls.Add(this.uiLabel2);
            this.折铁.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.折铁.Location = new System.Drawing.Point(148, 648);
            this.折铁.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.折铁.MinimumSize = new System.Drawing.Size(1, 1);
            this.折铁.Name = "折铁";
            this.折铁.Padding = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.折铁.Size = new System.Drawing.Size(585, 137);
            this.折铁.Style = Sunny.UI.UIStyle.Custom;
            this.折铁.TabIndex = 89;
            this.折铁.Text = "铁包信息";
            this.折铁.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // weight_speed_uiLabel
            // 
            this.weight_speed_uiLabel.BackColor = System.Drawing.Color.Transparent;
            this.weight_speed_uiLabel.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.weight_speed_uiLabel.Location = new System.Drawing.Point(436, 79);
            this.weight_speed_uiLabel.Name = "weight_speed_uiLabel";
            this.weight_speed_uiLabel.Size = new System.Drawing.Size(130, 40);
            this.weight_speed_uiLabel.Style = Sunny.UI.UIStyle.Custom;
            this.weight_speed_uiLabel.TabIndex = 90;
            this.weight_speed_uiLabel.Text = "0";
            this.weight_speed_uiLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel3
            // 
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel3.Location = new System.Drawing.Point(465, 37);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(101, 34);
            this.uiLabel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel3.TabIndex = 89;
            this.uiLabel3.Text = "重量增速：";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb_limit
            // 
            this.tb_limit.Color = System.Drawing.Color.Silver;
            this.tb_limit.Location = new System.Drawing.Point(111, 94);
            this.tb_limit.Name = "tb_limit";
            this.tb_limit.Size = new System.Drawing.Size(25, 25);
            this.tb_limit.TabIndex = 79;
            this.tb_limit.Text = "TB_limt";
            // 
            // TB_weight
            // 
            this.TB_weight.BackColor = System.Drawing.Color.Transparent;
            this.TB_weight.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.TB_weight.Location = new System.Drawing.Point(105, 39);
            this.TB_weight.Name = "TB_weight";
            this.TB_weight.Size = new System.Drawing.Size(99, 40);
            this.TB_weight.Style = Sunny.UI.UIStyle.Custom;
            this.TB_weight.TabIndex = 81;
            this.TB_weight.Text = "50t";
            this.TB_weight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // aim_weight_uiLabel3
            // 
            this.aim_weight_uiLabel3.BackColor = System.Drawing.Color.Transparent;
            this.aim_weight_uiLabel3.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.aim_weight_uiLabel3.Location = new System.Drawing.Point(293, 83);
            this.aim_weight_uiLabel3.Name = "aim_weight_uiLabel3";
            this.aim_weight_uiLabel3.Size = new System.Drawing.Size(130, 40);
            this.aim_weight_uiLabel3.Style = Sunny.UI.UIStyle.Custom;
            this.aim_weight_uiLabel3.TabIndex = 88;
            this.aim_weight_uiLabel3.Text = "50t";
            this.aim_weight_uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel7
            // 
            this.uiLabel7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel7.Location = new System.Drawing.Point(204, 89);
            this.uiLabel7.Name = "uiLabel7";
            this.uiLabel7.Size = new System.Drawing.Size(115, 34);
            this.uiLabel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel7.TabIndex = 87;
            this.uiLabel7.Text = "目标重量：";
            this.uiLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel18
            // 
            this.uiLabel18.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel18.Location = new System.Drawing.Point(14, 48);
            this.uiLabel18.Name = "uiLabel18";
            this.uiLabel18.Size = new System.Drawing.Size(115, 23);
            this.uiLabel18.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel18.TabIndex = 80;
            this.uiLabel18.Text = "台车称重：";
            this.uiLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel16
            // 
            this.uiLabel16.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel16.Location = new System.Drawing.Point(14, 94);
            this.uiLabel16.Name = "uiLabel16";
            this.uiLabel16.Size = new System.Drawing.Size(119, 25);
            this.uiLabel16.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel16.TabIndex = 78;
            this.uiLabel16.Text = "折铁限位：";
            this.uiLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TB_hight
            // 
            this.TB_hight.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.TB_hight.Location = new System.Drawing.Point(293, 39);
            this.TB_hight.Name = "TB_hight";
            this.TB_hight.Size = new System.Drawing.Size(130, 40);
            this.TB_hight.Style = Sunny.UI.UIStyle.Custom;
            this.TB_hight.TabIndex = 85;
            this.TB_hight.Text = "50t";
            this.TB_hight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel2
            // 
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel2.Location = new System.Drawing.Point(204, 46);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(120, 25);
            this.uiLabel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel2.TabIndex = 86;
            this.uiLabel2.Text = "铁包净空：";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // A_go
            // 
            this.A_go.CircleColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.FillColor = System.Drawing.Color.Transparent;
            this.A_go.FillDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.A_go.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_go.Location = new System.Drawing.Point(129, 96);
            this.A_go.MinimumSize = new System.Drawing.Size(1, 1);
            this.A_go.Name = "A_go";
            this.A_go.Padding = new System.Windows.Forms.Padding(0, 8, 0, 3);
            this.A_go.Radius = 0;
            this.A_go.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.A_go.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.A_go.Size = new System.Drawing.Size(39, 52);
            this.A_go.Style = Sunny.UI.UIStyle.Custom;
            this.A_go.StyleCustomMode = true;
            this.A_go.Symbol = 61539;
            this.A_go.SymbolColor = System.Drawing.Color.Transparent;
            this.A_go.TabIndex = 83;
            // 
            // B_go
            // 
            this.B_go.CircleColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.FillColor = System.Drawing.Color.Transparent;
            this.B_go.FillDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.B_go.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_go.Location = new System.Drawing.Point(722, 93);
            this.B_go.MinimumSize = new System.Drawing.Size(1, 1);
            this.B_go.Name = "B_go";
            this.B_go.Padding = new System.Windows.Forms.Padding(0, 8, 0, 3);
            this.B_go.Radius = 0;
            this.B_go.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.B_go.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.B_go.Size = new System.Drawing.Size(39, 52);
            this.B_go.Style = Sunny.UI.UIStyle.Custom;
            this.B_go.StyleCustomMode = true;
            this.B_go.Symbol = 61539;
            this.B_go.SymbolColor = System.Drawing.Color.Transparent;
            this.B_go.TabIndex = 81;
            // 
            // A_back
            // 
            this.A_back.CircleColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.FillColor = System.Drawing.Color.Transparent;
            this.A_back.FillDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.A_back.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.A_back.Location = new System.Drawing.Point(129, 38);
            this.A_back.MinimumSize = new System.Drawing.Size(1, 1);
            this.A_back.Name = "A_back";
            this.A_back.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.A_back.Radius = 0;
            this.A_back.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.A_back.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.A_back.Size = new System.Drawing.Size(39, 52);
            this.A_back.Style = Sunny.UI.UIStyle.Custom;
            this.A_back.StyleCustomMode = true;
            this.A_back.Symbol = 61538;
            this.A_back.SymbolColor = System.Drawing.Color.Transparent;
            this.A_back.TabIndex = 82;
            // 
            // B_back
            // 
            this.B_back.CircleColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.FillColor = System.Drawing.Color.Transparent;
            this.B_back.FillDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.B_back.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.B_back.Location = new System.Drawing.Point(722, 33);
            this.B_back.MinimumSize = new System.Drawing.Size(1, 1);
            this.B_back.Name = "B_back";
            this.B_back.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.B_back.Radius = 0;
            this.B_back.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.B_back.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.B_back.Size = new System.Drawing.Size(39, 52);
            this.B_back.Style = Sunny.UI.UIStyle.Custom;
            this.B_back.StyleCustomMode = true;
            this.B_back.Symbol = 61538;
            this.B_back.SymbolColor = System.Drawing.Color.Transparent;
            this.B_back.TabIndex = 80;
            this.B_back.Click += new System.EventHandler(this.B_back_Click);
            // 
            // TL_panel1
            // 
            this.TL_panel1.Controls.Add(this.main_tl_vmRenderControl1);
            this.TL_panel1.Location = new System.Drawing.Point(261, 165);
            this.TL_panel1.Name = "TL_panel1";
            this.TL_panel1.Size = new System.Drawing.Size(367, 283);
            this.TL_panel1.TabIndex = 78;
            // 
            // main_tl_vmRenderControl1
            // 
            this.main_tl_vmRenderControl1.BackColor = System.Drawing.Color.Black;
            this.main_tl_vmRenderControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.main_tl_vmRenderControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.main_tl_vmRenderControl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.main_tl_vmRenderControl1.ImageSource = null;
            this.main_tl_vmRenderControl1.Location = new System.Drawing.Point(0, 0);
            this.main_tl_vmRenderControl1.Margin = new System.Windows.Forms.Padding(38, 68, 38, 68);
            this.main_tl_vmRenderControl1.ModuleSource = null;
            this.main_tl_vmRenderControl1.Name = "main_tl_vmRenderControl1";
            this.main_tl_vmRenderControl1.Size = new System.Drawing.Size(367, 509);
            this.main_tl_vmRenderControl1.TabIndex = 81;
            // 
            // uiGroupBox2
            // 
            this.uiGroupBox2.Controls.Add(this.uiLabel31);
            this.uiGroupBox2.Controls.Add(this.B_MODEL);
            this.uiGroupBox2.Controls.Add(this.GBB_now_weight);
            this.uiGroupBox2.Controls.Add(this.uiLabel32);
            this.uiGroupBox2.Controls.Add(this.B_TBK_vision);
            this.uiGroupBox2.Controls.Add(this.ui_gbb_angle);
            this.uiGroupBox2.Controls.Add(this.uiLabel34);
            this.uiGroupBox2.Controls.Add(this.uiLabel10);
            this.uiGroupBox2.Controls.Add(this.B_120_uiLedBulb4);
            this.uiGroupBox2.Controls.Add(this.uiLabel35);
            this.uiGroupBox2.Controls.Add(this.uiLabel24);
            this.uiGroupBox2.Controls.Add(this.uiLabel25);
            this.uiGroupBox2.Controls.Add(this.B_0_uiLedBulb5);
            this.uiGroupBox2.Controls.Add(this.uiLabel28);
            this.uiGroupBox2.Controls.Add(this.uiLabel29);
            this.uiGroupBox2.Controls.Add(this.GBB_getpow);
            this.uiGroupBox2.Controls.Add(this.B_TL);
            this.uiGroupBox2.Controls.Add(this.GBB_num);
            this.uiGroupBox2.Controls.Add(this.uiLabel30);
            this.uiGroupBox2.Controls.Add(this.B_GBK_vision);
            this.uiGroupBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.uiGroupBox2.Location = new System.Drawing.Point(635, 148);
            this.uiGroupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiGroupBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiGroupBox2.Name = "uiGroupBox2";
            this.uiGroupBox2.Padding = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.uiGroupBox2.Size = new System.Drawing.Size(242, 453);
            this.uiGroupBox2.Style = Sunny.UI.UIStyle.Custom;
            this.uiGroupBox2.TabIndex = 64;
            this.uiGroupBox2.Text = "1号位折铁条件";
            this.uiGroupBox2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel31
            // 
            this.uiLabel31.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel31.Location = new System.Drawing.Point(13, 204);
            this.uiLabel31.Name = "uiLabel31";
            this.uiLabel31.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.uiLabel31.Size = new System.Drawing.Size(111, 23);
            this.uiLabel31.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel31.TabIndex = 90;
            this.uiLabel31.Text = "鱼雷倾角：";
            this.uiLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // B_MODEL
            // 
            this.B_MODEL.Color = System.Drawing.Color.Silver;
            this.B_MODEL.Location = new System.Drawing.Point(150, 34);
            this.B_MODEL.Name = "B_MODEL";
            this.B_MODEL.Size = new System.Drawing.Size(36, 23);
            this.B_MODEL.TabIndex = 97;
            this.B_MODEL.Text = "uiLedBulb3";
            // 
            // GBB_now_weight
            // 
            this.GBB_now_weight.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBB_now_weight.Location = new System.Drawing.Point(150, 160);
            this.GBB_now_weight.Name = "GBB_now_weight";
            this.GBB_now_weight.Size = new System.Drawing.Size(55, 23);
            this.GBB_now_weight.Style = Sunny.UI.UIStyle.Custom;
            this.GBB_now_weight.TabIndex = 79;
            this.GBB_now_weight.Text = "50t";
            this.GBB_now_weight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel32
            // 
            this.uiLabel32.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel32.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel32.Location = new System.Drawing.Point(13, 78);
            this.uiLabel32.Name = "uiLabel32";
            this.uiLabel32.Size = new System.Drawing.Size(111, 23);
            this.uiLabel32.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel32.TabIndex = 89;
            this.uiLabel32.Text = "罐车罐号：";
            this.uiLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // B_TBK_vision
            // 
            this.B_TBK_vision.Color = System.Drawing.Color.Silver;
            this.B_TBK_vision.Location = new System.Drawing.Point(150, 328);
            this.B_TBK_vision.Name = "B_TBK_vision";
            this.B_TBK_vision.Size = new System.Drawing.Size(36, 23);
            this.B_TBK_vision.TabIndex = 91;
            this.B_TBK_vision.Text = "uiLedBulb1";
            // 
            // ui_gbb_angle
            // 
            this.ui_gbb_angle.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ui_gbb_angle.Location = new System.Drawing.Point(150, 202);
            this.ui_gbb_angle.Name = "ui_gbb_angle";
            this.ui_gbb_angle.Size = new System.Drawing.Size(55, 23);
            this.ui_gbb_angle.Style = Sunny.UI.UIStyle.Custom;
            this.ui_gbb_angle.TabIndex = 83;
            this.ui_gbb_angle.Text = "0";
            this.ui_gbb_angle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel34
            // 
            this.uiLabel34.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel34.Location = new System.Drawing.Point(13, 162);
            this.uiLabel34.Name = "uiLabel34";
            this.uiLabel34.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.uiLabel34.Size = new System.Drawing.Size(111, 23);
            this.uiLabel34.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel34.TabIndex = 87;
            this.uiLabel34.Text = "余铁量：";
            this.uiLabel34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel10
            // 
            this.uiLabel10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel10.Location = new System.Drawing.Point(13, 36);
            this.uiLabel10.Name = "uiLabel10";
            this.uiLabel10.Size = new System.Drawing.Size(111, 23);
            this.uiLabel10.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel10.TabIndex = 96;
            this.uiLabel10.Text = "手自动：";
            this.uiLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // B_120_uiLedBulb4
            // 
            this.B_120_uiLedBulb4.Color = System.Drawing.Color.Silver;
            this.B_120_uiLedBulb4.Location = new System.Drawing.Point(150, 286);
            this.B_120_uiLedBulb4.Name = "B_120_uiLedBulb4";
            this.B_120_uiLedBulb4.Size = new System.Drawing.Size(36, 23);
            this.B_120_uiLedBulb4.TabIndex = 95;
            this.B_120_uiLedBulb4.Text = "A_uiLedBulb1";
            // 
            // uiLabel35
            // 
            this.uiLabel35.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel35.Location = new System.Drawing.Point(13, 120);
            this.uiLabel35.Name = "uiLabel35";
            this.uiLabel35.Size = new System.Drawing.Size(111, 23);
            this.uiLabel35.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel35.TabIndex = 86;
            this.uiLabel35.Text = "罐车得电：";
            this.uiLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel24
            // 
            this.uiLabel24.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel24.Location = new System.Drawing.Point(13, 330);
            this.uiLabel24.Name = "uiLabel24";
            this.uiLabel24.Size = new System.Drawing.Size(111, 23);
            this.uiLabel24.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel24.TabIndex = 90;
            this.uiLabel24.Text = "包口视觉：";
            this.uiLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel25
            // 
            this.uiLabel25.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel25.Location = new System.Drawing.Point(13, 288);
            this.uiLabel25.Name = "uiLabel25";
            this.uiLabel25.Size = new System.Drawing.Size(111, 23);
            this.uiLabel25.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel25.TabIndex = 94;
            this.uiLabel25.Text = "120限位:";
            this.uiLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // B_0_uiLedBulb5
            // 
            this.B_0_uiLedBulb5.Color = System.Drawing.Color.Silver;
            this.B_0_uiLedBulb5.Location = new System.Drawing.Point(150, 244);
            this.B_0_uiLedBulb5.Name = "B_0_uiLedBulb5";
            this.B_0_uiLedBulb5.Size = new System.Drawing.Size(36, 23);
            this.B_0_uiLedBulb5.TabIndex = 93;
            this.B_0_uiLedBulb5.Text = "A_uiLedBulb1";
            // 
            // uiLabel28
            // 
            this.uiLabel28.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel28.Location = new System.Drawing.Point(13, 372);
            this.uiLabel28.Name = "uiLabel28";
            this.uiLabel28.Size = new System.Drawing.Size(111, 23);
            this.uiLabel28.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel28.TabIndex = 86;
            this.uiLabel28.Text = "罐口视觉：";
            this.uiLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel29
            // 
            this.uiLabel29.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel29.Location = new System.Drawing.Point(13, 246);
            this.uiLabel29.Name = "uiLabel29";
            this.uiLabel29.Size = new System.Drawing.Size(111, 23);
            this.uiLabel29.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel29.TabIndex = 92;
            this.uiLabel29.Text = "0限位：";
            this.uiLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GBB_getpow
            // 
            this.GBB_getpow.Color = System.Drawing.Color.Silver;
            this.GBB_getpow.Location = new System.Drawing.Point(150, 118);
            this.GBB_getpow.Name = "GBB_getpow";
            this.GBB_getpow.Size = new System.Drawing.Size(36, 23);
            this.GBB_getpow.TabIndex = 81;
            this.GBB_getpow.Text = "uiLedBulb4";
            // 
            // B_TL
            // 
            this.B_TL.Color = System.Drawing.Color.Silver;
            this.B_TL.Location = new System.Drawing.Point(150, 412);
            this.B_TL.Name = "B_TL";
            this.B_TL.Size = new System.Drawing.Size(36, 23);
            this.B_TL.TabIndex = 89;
            this.B_TL.Text = "uiLedBulb3";
            // 
            // GBB_num
            // 
            this.GBB_num.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBB_num.Location = new System.Drawing.Point(150, 76);
            this.GBB_num.Name = "GBB_num";
            this.GBB_num.Size = new System.Drawing.Size(55, 23);
            this.GBB_num.Style = Sunny.UI.UIStyle.Custom;
            this.GBB_num.TabIndex = 77;
            this.GBB_num.Text = "50t";
            this.GBB_num.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel30
            // 
            this.uiLabel30.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel30.Location = new System.Drawing.Point(13, 414);
            this.uiLabel30.Name = "uiLabel30";
            this.uiLabel30.Size = new System.Drawing.Size(111, 23);
            this.uiLabel30.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel30.TabIndex = 87;
            this.uiLabel30.Text = "有无铁流：";
            this.uiLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // B_GBK_vision
            // 
            this.B_GBK_vision.Color = System.Drawing.Color.Silver;
            this.B_GBK_vision.Location = new System.Drawing.Point(150, 370);
            this.B_GBK_vision.Name = "B_GBK_vision";
            this.B_GBK_vision.Size = new System.Drawing.Size(36, 23);
            this.B_GBK_vision.TabIndex = 88;
            this.B_GBK_vision.Text = "uiLedBulb2";
            // 
            // uiGroupBox1
            // 
            this.uiGroupBox1.Controls.Add(this.A_MODEL);
            this.uiGroupBox1.Controls.Add(this.A_TBK_vision);
            this.uiGroupBox1.Controls.Add(this.A_120_uiLedBulb2);
            this.uiGroupBox1.Controls.Add(this.uiLabel9);
            this.uiGroupBox1.Controls.Add(this.uiLabel13);
            this.uiGroupBox1.Controls.Add(this.uiLabel8);
            this.uiGroupBox1.Controls.Add(this.A_0_uiLedBulb1);
            this.uiGroupBox1.Controls.Add(this.uiLabel4);
            this.uiGroupBox1.Controls.Add(this.uiLabel6);
            this.uiGroupBox1.Controls.Add(this.A_TL);
            this.uiGroupBox1.Controls.Add(this.ui_gba_angle);
            this.uiGroupBox1.Controls.Add(this.uiLabel5);
            this.uiGroupBox1.Controls.Add(this.uiLabel27);
            this.uiGroupBox1.Controls.Add(this.A_GBK_vision);
            this.uiGroupBox1.Controls.Add(this.GBA_getpow);
            this.uiGroupBox1.Controls.Add(this.GBA_num);
            this.uiGroupBox1.Controls.Add(this.uiLabel19);
            this.uiGroupBox1.Controls.Add(this.GBA_now_weight);
            this.uiGroupBox1.Controls.Add(this.uiLabel11);
            this.uiGroupBox1.Controls.Add(this.uiLabel1);
            this.uiGroupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.uiGroupBox1.Location = new System.Drawing.Point(4, 148);
            this.uiGroupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiGroupBox1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiGroupBox1.Name = "uiGroupBox1";
            this.uiGroupBox1.Padding = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.uiGroupBox1.Size = new System.Drawing.Size(242, 445);
            this.uiGroupBox1.Style = Sunny.UI.UIStyle.Custom;
            this.uiGroupBox1.TabIndex = 63;
            this.uiGroupBox1.Text = "2号位折铁条件";
            this.uiGroupBox1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiGroupBox1.Click += new System.EventHandler(this.uiGroupBox1_Click);
            // 
            // A_MODEL
            // 
            this.A_MODEL.Color = System.Drawing.Color.Silver;
            this.A_MODEL.Location = new System.Drawing.Point(140, 41);
            this.A_MODEL.Name = "A_MODEL";
            this.A_MODEL.Size = new System.Drawing.Size(25, 25);
            this.A_MODEL.TabIndex = 85;
            this.A_MODEL.Text = "uiLedBulb3";
            // 
            // A_TBK_vision
            // 
            this.A_TBK_vision.Color = System.Drawing.Color.Silver;
            this.A_TBK_vision.Location = new System.Drawing.Point(140, 321);
            this.A_TBK_vision.Name = "A_TBK_vision";
            this.A_TBK_vision.Size = new System.Drawing.Size(25, 25);
            this.A_TBK_vision.TabIndex = 73;
            this.A_TBK_vision.Text = "uiLedBulb1";
            // 
            // A_120_uiLedBulb2
            // 
            this.A_120_uiLedBulb2.Color = System.Drawing.Color.Silver;
            this.A_120_uiLedBulb2.Location = new System.Drawing.Point(140, 281);
            this.A_120_uiLedBulb2.Name = "A_120_uiLedBulb2";
            this.A_120_uiLedBulb2.Size = new System.Drawing.Size(25, 25);
            this.A_120_uiLedBulb2.TabIndex = 83;
            this.A_120_uiLedBulb2.Text = "A_uiLedBulb1";
            // 
            // uiLabel9
            // 
            this.uiLabel9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel9.Location = new System.Drawing.Point(13, 41);
            this.uiLabel9.Name = "uiLabel9";
            this.uiLabel9.Size = new System.Drawing.Size(109, 23);
            this.uiLabel9.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel9.TabIndex = 84;
            this.uiLabel9.Text = "手自动：";
            this.uiLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel13
            // 
            this.uiLabel13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel13.Location = new System.Drawing.Point(13, 321);
            this.uiLabel13.Name = "uiLabel13";
            this.uiLabel13.Size = new System.Drawing.Size(109, 23);
            this.uiLabel13.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel13.TabIndex = 72;
            this.uiLabel13.Text = "包口视觉：";
            this.uiLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel8
            // 
            this.uiLabel8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel8.Location = new System.Drawing.Point(13, 281);
            this.uiLabel8.Name = "uiLabel8";
            this.uiLabel8.Size = new System.Drawing.Size(109, 23);
            this.uiLabel8.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel8.TabIndex = 82;
            this.uiLabel8.Text = "120限位:";
            this.uiLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // A_0_uiLedBulb1
            // 
            this.A_0_uiLedBulb1.Color = System.Drawing.Color.Silver;
            this.A_0_uiLedBulb1.Location = new System.Drawing.Point(140, 241);
            this.A_0_uiLedBulb1.Name = "A_0_uiLedBulb1";
            this.A_0_uiLedBulb1.Size = new System.Drawing.Size(25, 25);
            this.A_0_uiLedBulb1.TabIndex = 81;
            this.A_0_uiLedBulb1.Text = "A_uiLedBulb1";
            // 
            // uiLabel4
            // 
            this.uiLabel4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel4.Location = new System.Drawing.Point(13, 361);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(109, 23);
            this.uiLabel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel4.TabIndex = 65;
            this.uiLabel4.Text = "罐口视觉：";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel6
            // 
            this.uiLabel6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel6.Location = new System.Drawing.Point(13, 241);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Size = new System.Drawing.Size(109, 23);
            this.uiLabel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel6.TabIndex = 80;
            this.uiLabel6.Text = "0限位：";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // A_TL
            // 
            this.A_TL.Color = System.Drawing.Color.Silver;
            this.A_TL.Location = new System.Drawing.Point(140, 401);
            this.A_TL.Name = "A_TL";
            this.A_TL.Size = new System.Drawing.Size(25, 25);
            this.A_TL.TabIndex = 69;
            this.A_TL.Text = "uiLedBulb3";
            // 
            // ui_gba_angle
            // 
            this.ui_gba_angle.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ui_gba_angle.Location = new System.Drawing.Point(140, 201);
            this.ui_gba_angle.Name = "ui_gba_angle";
            this.ui_gba_angle.Size = new System.Drawing.Size(53, 25);
            this.ui_gba_angle.Style = Sunny.UI.UIStyle.Custom;
            this.ui_gba_angle.TabIndex = 79;
            this.ui_gba_angle.Text = "0";
            this.ui_gba_angle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel5
            // 
            this.uiLabel5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel5.Location = new System.Drawing.Point(13, 401);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Size = new System.Drawing.Size(109, 23);
            this.uiLabel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel5.TabIndex = 66;
            this.uiLabel5.Text = "有无铁流：";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel27
            // 
            this.uiLabel27.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel27.Location = new System.Drawing.Point(13, 201);
            this.uiLabel27.Name = "uiLabel27";
            this.uiLabel27.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.uiLabel27.Size = new System.Drawing.Size(109, 23);
            this.uiLabel27.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel27.TabIndex = 78;
            this.uiLabel27.Text = "鱼雷倾角：";
            this.uiLabel27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // A_GBK_vision
            // 
            this.A_GBK_vision.Color = System.Drawing.Color.Silver;
            this.A_GBK_vision.Location = new System.Drawing.Point(140, 361);
            this.A_GBK_vision.Name = "A_GBK_vision";
            this.A_GBK_vision.Size = new System.Drawing.Size(25, 25);
            this.A_GBK_vision.TabIndex = 68;
            this.A_GBK_vision.Text = "uiLedBulb2";
            // 
            // GBA_getpow
            // 
            this.GBA_getpow.Color = System.Drawing.Color.Silver;
            this.GBA_getpow.Location = new System.Drawing.Point(140, 121);
            this.GBA_getpow.Name = "GBA_getpow";
            this.GBA_getpow.Size = new System.Drawing.Size(25, 25);
            this.GBA_getpow.TabIndex = 75;
            this.GBA_getpow.Text = "uiLedBulb1";
            // 
            // GBA_num
            // 
            this.GBA_num.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBA_num.Location = new System.Drawing.Point(140, 81);
            this.GBA_num.Name = "GBA_num";
            this.GBA_num.Size = new System.Drawing.Size(53, 25);
            this.GBA_num.Style = Sunny.UI.UIStyle.Custom;
            this.GBA_num.TabIndex = 75;
            this.GBA_num.Text = "50t";
            this.GBA_num.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel19
            // 
            this.uiLabel19.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel19.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel19.Location = new System.Drawing.Point(13, 81);
            this.uiLabel19.Name = "uiLabel19";
            this.uiLabel19.Size = new System.Drawing.Size(109, 23);
            this.uiLabel19.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel19.TabIndex = 74;
            this.uiLabel19.Text = "罐车罐号：";
            this.uiLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GBA_now_weight
            // 
            this.GBA_now_weight.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBA_now_weight.Location = new System.Drawing.Point(140, 161);
            this.GBA_now_weight.Name = "GBA_now_weight";
            this.GBA_now_weight.Size = new System.Drawing.Size(53, 25);
            this.GBA_now_weight.Style = Sunny.UI.UIStyle.Custom;
            this.GBA_now_weight.TabIndex = 71;
            this.GBA_now_weight.Text = "50t";
            this.GBA_now_weight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel11
            // 
            this.uiLabel11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel11.Location = new System.Drawing.Point(13, 161);
            this.uiLabel11.Name = "uiLabel11";
            this.uiLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.uiLabel11.Size = new System.Drawing.Size(109, 23);
            this.uiLabel11.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel11.TabIndex = 70;
            this.uiLabel11.Text = "余铁量：";
            this.uiLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel1
            // 
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel1.Location = new System.Drawing.Point(13, 121);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(109, 23);
            this.uiLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel1.TabIndex = 62;
            this.uiLabel1.Text = "罐车得电：";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GBB_img
            // 
            this.GBB_img.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GBB_img.Enabled = false;
            this.GBB_img.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBB_img.Image = ((System.Drawing.Image)(resources.GetObject("GBB_img.Image")));
            this.GBB_img.ImageDisabled = ((System.Drawing.Image)(resources.GetObject("GBB_img.ImageDisabled")));
            this.GBB_img.Location = new System.Drawing.Point(536, 50);
            this.GBB_img.Name = "GBB_img";
            this.GBB_img.Size = new System.Drawing.Size(178, 90);
            this.GBB_img.TabIndex = 56;
            this.GBB_img.TabStop = false;
            this.GBB_img.Text = null;
            this.GBB_img.Click += new System.EventHandler(this.GBB_img_Click);
            // 
            // GBA_img
            // 
            this.GBA_img.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GBA_img.Enabled = false;
            this.GBA_img.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.GBA_img.Image = ((System.Drawing.Image)(resources.GetObject("GBA_img.Image")));
            this.GBA_img.ImageDisabled = ((System.Drawing.Image)(resources.GetObject("GBA_img.ImageDisabled")));
            this.GBA_img.Location = new System.Drawing.Point(176, 50);
            this.GBA_img.Name = "GBA_img";
            this.GBA_img.Size = new System.Drawing.Size(175, 90);
            this.GBA_img.TabIndex = 55;
            this.GBA_img.TabStop = false;
            this.GBA_img.Text = null;
            this.GBA_img.Click += new System.EventHandler(this.GBA_img_Click);
            // 
            // cw_Panel2
            // 
            this.cw_Panel2.Controls.Add(this.temp_weight);
            this.cw_Panel2.Controls.Add(this.uiLabel21);
            this.cw_Panel2.Controls.Add(this.CW_tbnum);
            this.cw_Panel2.Controls.Add(this.uiLabel17);
            this.cw_Panel2.Controls.Add(this.uiProcessBar2);
            this.cw_Panel2.Controls.Add(this.uiScrollingText2);
            this.cw_Panel2.Enabled = false;
            this.cw_Panel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.cw_Panel2.Location = new System.Drawing.Point(898, 38);
            this.cw_Panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cw_Panel2.MinimumSize = new System.Drawing.Size(1, 1);
            this.cw_Panel2.Name = "cw_Panel2";
            this.cw_Panel2.RectColor = System.Drawing.Color.Red;
            this.cw_Panel2.Size = new System.Drawing.Size(379, 400);
            this.cw_Panel2.Style = Sunny.UI.UIStyle.Custom;
            this.cw_Panel2.StyleCustomMode = true;
            this.cw_Panel2.TabIndex = 57;
            this.cw_Panel2.Text = null;
            this.cw_Panel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // temp_weight
            // 
            this.temp_weight.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.temp_weight.Location = new System.Drawing.Point(120, 92);
            this.temp_weight.Name = "temp_weight";
            this.temp_weight.Size = new System.Drawing.Size(49, 23);
            this.temp_weight.Style = Sunny.UI.UIStyle.Custom;
            this.temp_weight.TabIndex = 89;
            this.temp_weight.Text = "8";
            this.temp_weight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel21
            // 
            this.uiLabel21.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel21.Location = new System.Drawing.Point(42, 92);
            this.uiLabel21.Name = "uiLabel21";
            this.uiLabel21.Size = new System.Drawing.Size(102, 23);
            this.uiLabel21.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel21.TabIndex = 88;
            this.uiLabel21.Text = "铁包重：";
            this.uiLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CW_tbnum
            // 
            this.CW_tbnum.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.CW_tbnum.Location = new System.Drawing.Point(120, 51);
            this.CW_tbnum.Name = "CW_tbnum";
            this.CW_tbnum.Size = new System.Drawing.Size(49, 23);
            this.CW_tbnum.Style = Sunny.UI.UIStyle.Custom;
            this.CW_tbnum.TabIndex = 87;
            this.CW_tbnum.Text = "8";
            this.CW_tbnum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel17
            // 
            this.uiLabel17.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel17.Location = new System.Drawing.Point(42, 51);
            this.uiLabel17.Name = "uiLabel17";
            this.uiLabel17.Size = new System.Drawing.Size(102, 23);
            this.uiLabel17.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel17.TabIndex = 86;
            this.uiLabel17.Text = "铁包号：";
            this.uiLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiProcessBar2
            // 
            this.uiProcessBar2.BackColor = System.Drawing.Color.Transparent;
            this.uiProcessBar2.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiProcessBar2.Enabled = false;
            this.uiProcessBar2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiProcessBar2.ForeColor = System.Drawing.Color.Black;
            this.uiProcessBar2.Location = new System.Drawing.Point(125, 183);
            this.uiProcessBar2.Maximum = 220;
            this.uiProcessBar2.MinimumSize = new System.Drawing.Size(70, 5);
            this.uiProcessBar2.Name = "uiProcessBar2";
            this.uiProcessBar2.Radius = 50;
            this.uiProcessBar2.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightBottom | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiProcessBar2.RectColor = System.Drawing.Color.Red;
            this.uiProcessBar2.Size = new System.Drawing.Size(138, 132);
            this.uiProcessBar2.Style = Sunny.UI.UIStyle.Custom;
            this.uiProcessBar2.StyleCustomMode = true;
            this.uiProcessBar2.TabIndex = 75;
            this.uiProcessBar2.Text = "uiProcessBar2";
            // 
            // uiScrollingText2
            // 
            this.uiScrollingText2.BackColor = System.Drawing.Color.Transparent;
            this.uiScrollingText2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiScrollingText2.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiScrollingText2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiScrollingText2.Location = new System.Drawing.Point(104, 321);
            this.uiScrollingText2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiScrollingText2.Name = "uiScrollingText2";
            this.uiScrollingText2.Size = new System.Drawing.Size(180, 24);
            this.uiScrollingText2.Style = Sunny.UI.UIStyle.Custom;
            this.uiScrollingText2.TabIndex = 76;
            this.uiScrollingText2.Text = "铁水包测温位";
            // 
            // dz_Panel3
            // 
            this.dz_Panel3.Controls.Add(this.dz_weight);
            this.dz_Panel3.Controls.Add(this.uiLabel23);
            this.dz_Panel3.Controls.Add(this.DZ_tbnum);
            this.dz_Panel3.Controls.Add(this.uiLabel20);
            this.dz_Panel3.Controls.Add(this.uiProcessBar3);
            this.dz_Panel3.Controls.Add(this.uiScrollingText3);
            this.dz_Panel3.Enabled = false;
            this.dz_Panel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dz_Panel3.Location = new System.Drawing.Point(898, 448);
            this.dz_Panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dz_Panel3.MinimumSize = new System.Drawing.Size(1, 1);
            this.dz_Panel3.Name = "dz_Panel3";
            this.dz_Panel3.RectColor = System.Drawing.Color.Red;
            this.dz_Panel3.Size = new System.Drawing.Size(379, 394);
            this.dz_Panel3.Style = Sunny.UI.UIStyle.Custom;
            this.dz_Panel3.StyleCustomMode = true;
            this.dz_Panel3.TabIndex = 58;
            this.dz_Panel3.Text = null;
            this.dz_Panel3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dz_weight
            // 
            this.dz_weight.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.dz_weight.Location = new System.Drawing.Point(120, 86);
            this.dz_weight.Name = "dz_weight";
            this.dz_weight.Size = new System.Drawing.Size(49, 23);
            this.dz_weight.Style = Sunny.UI.UIStyle.Custom;
            this.dz_weight.TabIndex = 87;
            this.dz_weight.Text = "8";
            this.dz_weight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel23
            // 
            this.uiLabel23.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel23.Location = new System.Drawing.Point(42, 86);
            this.uiLabel23.Name = "uiLabel23";
            this.uiLabel23.Size = new System.Drawing.Size(107, 23);
            this.uiLabel23.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel23.TabIndex = 86;
            this.uiLabel23.Text = "铁包重：";
            this.uiLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DZ_tbnum
            // 
            this.DZ_tbnum.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.DZ_tbnum.Location = new System.Drawing.Point(120, 47);
            this.DZ_tbnum.Name = "DZ_tbnum";
            this.DZ_tbnum.Size = new System.Drawing.Size(49, 23);
            this.DZ_tbnum.Style = Sunny.UI.UIStyle.Custom;
            this.DZ_tbnum.TabIndex = 85;
            this.DZ_tbnum.Text = "8";
            this.DZ_tbnum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel20
            // 
            this.uiLabel20.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel20.Location = new System.Drawing.Point(37, 47);
            this.uiLabel20.Name = "uiLabel20";
            this.uiLabel20.Size = new System.Drawing.Size(107, 23);
            this.uiLabel20.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel20.TabIndex = 84;
            this.uiLabel20.Text = "铁包号：";
            this.uiLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiProcessBar3
            // 
            this.uiProcessBar3.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiProcessBar3.Enabled = false;
            this.uiProcessBar3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiProcessBar3.ForeColor = System.Drawing.Color.Black;
            this.uiProcessBar3.Location = new System.Drawing.Point(124, 176);
            this.uiProcessBar3.Maximum = 190;
            this.uiProcessBar3.MinimumSize = new System.Drawing.Size(70, 5);
            this.uiProcessBar3.Name = "uiProcessBar3";
            this.uiProcessBar3.Radius = 50;
            this.uiProcessBar3.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightBottom | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiProcessBar3.RectColor = System.Drawing.Color.Red;
            this.uiProcessBar3.Size = new System.Drawing.Size(138, 132);
            this.uiProcessBar3.Style = Sunny.UI.UIStyle.Custom;
            this.uiProcessBar3.StyleCustomMode = true;
            this.uiProcessBar3.TabIndex = 77;
            this.uiProcessBar3.Text = "uiProcessBar3";
            // 
            // uiScrollingText3
            // 
            this.uiScrollingText3.BackColor = System.Drawing.Color.Transparent;
            this.uiScrollingText3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiScrollingText3.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiScrollingText3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiScrollingText3.Location = new System.Drawing.Point(103, 314);
            this.uiScrollingText3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiScrollingText3.Name = "uiScrollingText3";
            this.uiScrollingText3.Size = new System.Drawing.Size(180, 24);
            this.uiScrollingText3.Style = Sunny.UI.UIStyle.Custom;
            this.uiScrollingText3.TabIndex = 78;
            this.uiScrollingText3.Text = "铁水包吊装位";
            // 
            // Main_process
            // 
            this.AllowShowTitle = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1287, 852);
            this.ControlBox = false;
            this.Controls.Add(this.dz_Panel3);
            this.Controls.Add(this.cw_Panel2);
            this.Controls.Add(this.zt_Panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main_process";
            this.Padding = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.ShowDragStretch = true;
            this.ShowInTaskbar = false;
            this.ShowRadius = false;
            this.ShowTitle = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "折铁流程";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_process_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_process_FormClosed);
            this.Load += new System.EventHandler(this.Main_process_Load);
            this.zt_Panel1.ResumeLayout(false);
            this.zt_Panel1.PerformLayout();
            this.折铁.ResumeLayout(false);
            this.TL_panel1.ResumeLayout(false);
            this.uiGroupBox2.ResumeLayout(false);
            this.uiGroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GBB_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GBA_img)).EndInit();
            this.cw_Panel2.ResumeLayout(false);
            this.dz_Panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIProcessBar uiProcessBar1;
        private Sunny.UI.UIScrollingText zt_ScrollingText1;
        private Sunny.UI.UIPanel zt_Panel1;
        private Sunny.UI.UIImageButton GBA_img;
        private Sunny.UI.UIImageButton GBB_img;
        private Sunny.UI.UIGroupBox uiGroupBox2;
        private Sunny.UI.UIGroupBox uiGroupBox1;
        private Sunny.UI.UILedBulb A_TL;
        private Sunny.UI.UILedBulb A_GBK_vision;
        private Sunny.UI.UILabel uiLabel5;
        private Sunny.UI.UILabel uiLabel4;
        private Sunny.UI.UILabel GBA_now_weight;
        private Sunny.UI.UILedBulb GBB_getpow;
        private Sunny.UI.UILabel GBB_now_weight;
        private Sunny.UI.UILabel GBB_num;
        private Sunny.UI.UILabel TB_weight;
        private Sunny.UI.UILabel uiLabel18;
        private Sunny.UI.UILedBulb tb_limit;
        private Sunny.UI.UILabel uiLabel16;
        private Sunny.UI.UILedBulb A_TBK_vision;
        private Sunny.UI.UILabel uiLabel13;
        private Sunny.UI.UILabel uiLabel11;
        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UILabel GBA_num;
        private Sunny.UI.UILabel uiLabel19;
        private Sunny.UI.UIPanel cw_Panel2;
        private Sunny.UI.UIProcessBar uiProcessBar2;
        private Sunny.UI.UIScrollingText uiScrollingText2;
        private Sunny.UI.UIPanel dz_Panel3;
        private Sunny.UI.UIProcessBar uiProcessBar3;
        private Sunny.UI.UIScrollingText uiScrollingText3;
        private Sunny.UI.UILabel CW_tbnum;
        private Sunny.UI.UILabel uiLabel17;
        private Sunny.UI.UILabel DZ_tbnum;
        private Sunny.UI.UILabel uiLabel20;
        private Sunny.UI.UILedBulb GBA_getpow;
        private Sunny.UI.UILabel temp_weight;
        private Sunny.UI.UILabel uiLabel21;
        private Sunny.UI.UILabel dz_weight;
        private Sunny.UI.UILabel uiLabel23;
        private Sunny.UI.UILabel ui_gbb_angle;
        private Sunny.UI.UILabel ui_gba_angle;
        private Sunny.UI.UILabel uiLabel27;
        private Sunny.UI.UILabel TB_hight;
        private System.Windows.Forms.Panel TL_panel1;
        private VMControls.Winform.Release.VmRenderControl main_tl_vmRenderControl1;
        private Sunny.UI.UIHeaderButton A_go;
        private Sunny.UI.UIHeaderButton B_go;
        private Sunny.UI.UIHeaderButton A_back;
        private Sunny.UI.UIHeaderButton B_back;
        private Sunny.UI.UILedBulb A_120_uiLedBulb2;
        private Sunny.UI.UILabel uiLabel8;
        private Sunny.UI.UILedBulb A_0_uiLedBulb1;
        private Sunny.UI.UILabel uiLabel6;
        private Sunny.UI.UILabel uiLabel31;
        private Sunny.UI.UILedBulb B_MODEL;
        private Sunny.UI.UILabel uiLabel32;
        private Sunny.UI.UILedBulb B_TBK_vision;
        private Sunny.UI.UILabel uiLabel34;
        private Sunny.UI.UILedBulb B_120_uiLedBulb4;
        private Sunny.UI.UILabel uiLabel10;
        private Sunny.UI.UILabel uiLabel35;
        private Sunny.UI.UILabel uiLabel24;
        private Sunny.UI.UILabel uiLabel25;
        private Sunny.UI.UILedBulb B_0_uiLedBulb5;
        private Sunny.UI.UILabel uiLabel28;
        private Sunny.UI.UILabel uiLabel29;
        private Sunny.UI.UILedBulb B_TL;
        private Sunny.UI.UILabel uiLabel30;
        private Sunny.UI.UILedBulb B_GBK_vision;
        private Sunny.UI.UILedBulb A_MODEL;
        private Sunny.UI.UILabel uiLabel9;
        private Sunny.UI.UILabel aim_weight_uiLabel3;
        private Sunny.UI.UILabel uiLabel7;
        private Sunny.UI.UILabel uiLabel2;
        private Sunny.UI.UIGroupBox 折铁;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UIButton uiButton1;
        private Sunny.UI.UIButton uiButton1_back;
        private Sunny.UI.UILabel weight_speed_uiLabel;
        private Sunny.UI.UILabel uiLabel3;
    }
}

